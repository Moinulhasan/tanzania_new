<?php
/**
 * Created by PhpStorm.
 * User: Jream
 * Date: 5/30/2021
 * Time: 9:22 PM
 */
return [
	'switcher' => [
		'css' => ['gmz-switches'],
		'js' => []
	],
	'checkbox' => [
		'css' => ['gmz-checkbox'],
		'js' => []
	],
	'color_picker' => [
		'css' => ['gmz-spectrum'],
		'js' => ['gmz-spectrum']
	],
];