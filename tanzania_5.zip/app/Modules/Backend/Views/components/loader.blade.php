<?php
/**
 * Created by PhpStorm.
 * User: Jream
 * Date: 5/13/2020
 * Time: 11:17 PM
 */
?>
<div class="gmz-loader @if(isset($page)) gmz-page-loader @endif">
    <div class="loader-inner">
        <div class="spinner-grow text-info align-self-center loader-lg"></div>
    </div>
</div>
