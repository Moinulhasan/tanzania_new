@php
    admin_enqueue_styles('flatpickr');
    admin_enqueue_scripts('flatpickr');
@endphp
<div class="modal fade" id="gmzCouponModal" tabindex="-1" role="dialog" aria-labelledby="newCouponModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="render">
            </div>
        </div>
    </div>
</div>