<div class="modal fade" id="gmzUserModal" tabindex="-1" role="dialog" aria-labelledby="newUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="render">
            </div>
        </div>
    </div>
</div>