<div class="modal fade media-item-modal" id="gmz-media-item-modal" tabindex="-1" role="dialog" aria-labelledby="newMediaModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="render">
            </div>
        </div>
    </div>
</div>