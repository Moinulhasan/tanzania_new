<div class="modal fade" id="gmzPaymentModal" tabindex="-1" role="dialog" aria-labelledby="newPaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="render">
            </div>
        </div>
    </div>
</div>