<?php
return [
    'translations' => [
        __('Categories'),
        __('Tags'),
        __('Car Types'),
        __('Car Features'),
        __('Car Equipments'),
        __('Apartment Types'),
        __('Apartment Amenities'),
        __('Property Types'),
        __('Hotel Facilities'),
        __('Hotel Services'),
        __('Room Facilities'),
        __('Service Categories'),
        __('Beauty Branch'),
        __('Space Types'),
        __('Space Amenities'),
        __('Tour Types'),
        __('Tour Include'),
        __('Tour Exclude'),
        __('New Tour Include'),
        __('New Tour Exclude'),
        __('Edit Tour Include'),
        __('Edit Tour Exclude'),
    ]
];